import './CustMain.css';
import { useNavigate, useLocation } from 'react-router-dom';
import { StoreContext } from './StoreContext';
import { useContext, useState, useEffect } from 'react';
import CustHeader from './CustHeader';
import Plus from '../../assets/plus.png';
import Minus from '../../assets/minus.png';

function CustFoodDesc(){

    const navigate = useNavigate();
    const { state } = useLocation();
    const [comment, setComment] = useState('')
    const {url, cartItems, addToCart, removeFromCart} = useContext(StoreContext);

    if (!state) {
        return <p>Error: No food data found</p>
    }
    const {id, name, desc, image, quantity, businessId} = state;
    
    const initialQty = () => (Number(cartItems[id]) || 1);
    const [localQty, setLocalQty] = useState(initialQty)

    useEffect(() => {
        const qty = Number(cartItems[id] || 1);
        setLocalQty(qty)
    }, [cartItems, id])

    return(
        <>
            <CustHeader/>
            <div>
                <img className='card-image' src={url+"/images/"+image} alt=""/>
                <div className='food-desc-content'>
                    <h2 className='card-title'>{name}</h2>
                    <p className='card-text'>{desc}</p>
                    <div className='food-qty'>
                        <img onClick={()=>setLocalQty(prev => Math.max(Number(prev) - 1, 1))} src={Minus} alt=""/>
                        <div>{localQty}</div>
                        <img onClick={()=>setLocalQty(prev => Math.min(Number(prev) + 1, 10))} src={Plus} alt=""/>
                    </div>
                    <h2>{businessId?.name}</h2>
                    <button>View Restaurant</button>
                    <label htmlFor="comment">Add a note to the restaurant</label>
                    <textarea id='comment' placeholder='e.g. No onions' value={comment} onChange={(e) => setComment(e.target.value)} rows={3}
                        style={{width: "90%", padding: "18px", marginTop: "8px"}}/>
                    <button className='card-button' onClick={() => {
                        const alreadyInCart = cartItems[id] || 0
                        if (localQty > quantity) {
                            alert("Requested quantity exceeds what restaurant can supply")
                            return;
                        }

                        const safeQtyToAdd = localQty - alreadyInCart
                        if (safeQtyToAdd > 0)
                            for (let i = 0; i < safeQtyToAdd; i++){
                                addToCart(id)
                            }
                        alert("Item(s) added to basket")
                    }
                    }>Add to basket</button>
                </div>
            </div>

        </>
    )
}


export default CustFoodDesc;



function Header(){

    return (
        <header>
            <h1>FoodForAll</h1>
            <nav>
                <u1>
                    <li><a href="#">Login</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">About Us</a></li>
                </u1>
            </nav>
            <hr></hr>
        </header>
    );
}

export default Header
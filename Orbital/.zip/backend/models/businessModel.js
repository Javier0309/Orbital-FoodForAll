import mongoose from "mongoose";

const businessSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, required: true, unique: true, ref: 'User'},
    name: { type: String, required: true },
    yearEstablished: { type: Number  },
    about: { type: String },
    address: { type: String, required: true },
    hygieneCertUrl: { type: String, required: true  },
    businessLicenseUrl: { type: String, required: true  },
    halalCertUrl: { type: String },
    recommendedItems: [{ type: String }],
    email: { type: String, required: true, unique: true },
    createdAt: { type: Date, default: Date.now },
    isVerified: {type:Boolean, default: false},
    isOpen: {type: Boolean, default: true}
});

const businessModel = mongoose.models.business || mongoose.model("Business", businessSchema)
export default businessModel